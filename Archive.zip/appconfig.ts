export const TOKEN_SECRET = 'cfgvhjkhgfcvg';
export const MAP_SECRET_KEY = 'esAonottpernenaBNACerFoLtncntyae';     